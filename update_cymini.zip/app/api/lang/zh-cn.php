<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2024/08/15 01:36
 * file name : zh-cn.php
 * User: asusa
 * Author: Hyy-Cary（优）
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */
return [
    'email_send' => '邮件已发送',
    'email_error' => '邮件发送失败',
];