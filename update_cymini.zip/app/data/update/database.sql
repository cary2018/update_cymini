alter table cy_article add uid int not null default 0 comment'所属用户' after cid;
alter table cy_article add recycle tinyint(1) not null default 0 comment'回收站' after status;
alter table cy_admin add group_id tinyint(1) not null default 0 COMMENT'用户分组' after path;
alter table cy_category add share tinyint(1) not null default 0 comment'会员共享' after isShow;
create table `cy_domain`(
    id int(11) not null primary key auto_increment,
    web_domain varchar(130) not null default '' comment'网站域名',
    web_logo varchar(130) not null default '' comment'网站logo',
    web_title varchar(60) not null default '' comment'标题',
    web_key varchar(100) not null default '' comment'关键字',
    web_desc varchar(200) not null default '' comment'描述',
    web_Copyright text not null default '' comment'备案信息',
    web_Copy text not null default '' comment'版权信息',
    web_footer_title varchar(350) not null default '' comment'底部标语|其他',
    view_path varchar(50) not null default '' comment'网站模板',
    createTime int not null default 0 comment'创建时间',
    updateTime int not null default 0 comment'创建时间'
)engine=myisam charset=utf8 comment='站群配置表';
alter table cy_domain add web_ico varchar(130) not null default '' comment'ico图标' after web_logo;