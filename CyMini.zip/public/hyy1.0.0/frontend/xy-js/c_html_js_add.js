var zbpConfig = {
    comment: {
        useDefaultEvents: true,
    }
};
var zbp = new ZBP(zbpConfig);

var bloghost = zbp.options.bloghost;
