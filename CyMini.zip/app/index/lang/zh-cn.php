<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2024/07/11 23:32
 * file name : zh-cn.php
 * User: asusa
 * Author: Hyy-Cary（优）
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */
return [
    'visit_system' => '操作系统：',
    'browser' => '浏览器为：',
    'browser_lang' => '浏览器语言：',
    'browser_error' => '获取浏览器信息失败！',
    'browser_lang_error' => '获取浏览器语言失败！',
    'email_send' => '邮件已发送',
    'email_error' => '邮件发送失败',
];