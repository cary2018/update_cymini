<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2023/09/27 23:49
 * file name : Tags.php
 * User: asusa
 * Author: Hyy-Cary
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */


namespace app\index\controller;


use app\index\BaseController;

class Tags extends BaseController
{
    public function index(){
        $tag = request()->param('tag');
        if(!$tag){
            return redirect('/');
        }
        return View();
    }
}