<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2023/10/27 01:28
 * file name : CollectionContent.php
 * User: asusa
 * Author: Hyy-Cary
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */


namespace app\admin\model;


use think\Model;

class CollectionContent extends Model
{

}