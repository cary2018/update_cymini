<?php /*a:2:{s:47:"D:\web\tp\tp8\app\admin\view\welcome\index.html";i:1721455526;s:48:"D:\web\tp\tp8\app\admin\view\public\file_js.html";i:1703250444;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>首页二</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/hyy1.0.0/lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="/hyy1.0.0/lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/hyy1.0.0/css/public.css" media="all">
    <style>
        .layui-card {border:1px solid #f2f2f2;border-radius:5px;}
        .icon {margin-right:10px;color:#1aa094;}
        .icon-cray {color:#ffb800!important;}
        .icon-blue {color:#1e9fff!important;}
        .icon-tip {color:#ff5722!important;}
        .layuimini-qiuck-module {text-align:center;margin-top: 10px}
        .layuimini-qiuck-module a i {display:inline-block;width:100%;height:60px;line-height:60px;text-align:center;border-radius:2px;font-size:30px;background-color:#F8F8F8;color:#333;transition:all .3s;-webkit-transition:all .3s;}
        .layuimini-qiuck-module a cite {position:relative;top:2px;display:block;color:#666;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;font-size:14px;}
        .welcome-module {width:100%;height:210px;}
        .panel {background-color:#fff;border:1px solid transparent;border-radius:3px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05)}
        .panel-body {padding:10px}
        .panel-title {margin-top:0;margin-bottom:0;font-size:12px;color:inherit}
        .label {display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em;margin-top: .3em;}
        .layui-red {color:red}
        .main_btn > p {height:40px;}
        .layui-bg-number {background-color:#F8F8F8;}
        .layuimini-notice:hover {background:#f6f6f6;}
        .layuimini-notice {padding:7px 16px;clear:both;font-size:12px !important;cursor:pointer;position:relative;transition:background 0.2s ease-in-out;}
        .layuimini-notice-title,.layuimini-notice-label {
            padding-right: 70px !important;text-overflow:ellipsis!important;overflow:hidden!important;white-space:nowrap!important;}
        .layuimini-notice-title {line-height:28px;font-size:14px;}
        .layuimini-notice-extra {position:absolute;top:50%;margin-top:-8px;right:16px;display:inline-block;height:16px;color:#999;}
        .update{font-size:18px;color:#0c60ee;}
        .update a{font-size:18px;color:#0c60ee;}
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md8">

                <div class="layui-card">
                    <?php if($updatesql['code'] == '200'): ?>
                    <div id="layerDemo" class="layui-card-header update">
                        <a href="javascript:;" data-method="UpdateSql" >【<?php echo htmlentities($updatesql['msg']); ?>】</a>
                    </div>
                    <?php endif; if($update['code'] == '200'): ?>
                    <div id="layerDemo" class="layui-card-body update">
                        <a href="javascript:;" data-method="OnlineUpdate" >【<?php echo htmlentities($update['online']); ?>】</a>
                        <a href="<?php echo htmlentities($update['github']); ?>" target="_blank">【<?php echo htmlentities($update['download']); ?>】</a>
                        <a href="<?php echo htmlentities($update['gitee']); ?>" target="_blank">【<?php echo htmlentities($update['download2']); ?>】</a>
                    </div>
                    <?php else: ?>
                    <div class="layui-card-header update"><?php echo htmlentities($update['msg']); ?></div>
                    <?php endif; if($update['code'] == '200'): ?>
                    <div class="layui-card-body">
                        <span class="layui-btn layui-btn-danger layui-btn-xs"><?php echo htmlentities($update['version']); ?></span><br>
                        <?php echo $update['desc']; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="layui-row layui-col-space15">
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-warning icon"></i><?php echo htmlentities(lang('data_count')); ?></div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10">
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue"><?php echo htmlentities(lang('data_real')); ?></span>
                                                        <h5><?php echo htmlentities(lang('data_count_article')); ?></h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo htmlentities($article); ?></h1>
                                                        <small><?php echo htmlentities(lang('data_cate_count')); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-cyan"><?php echo htmlentities(lang('data_real')); ?></span>
                                                        <h5><?php echo htmlentities(lang('data_count_nav')); ?></h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo htmlentities($nav); ?></h1>
                                                        <small><?php echo htmlentities(lang('data_cate_count')); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-orange"><?php echo htmlentities(lang('data_real')); ?></span>
                                                        <h5><?php echo htmlentities(lang('data_count_today')); ?></h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo htmlentities($views); ?> / <?php echo htmlentities($today); ?></h1>
                                                        <small><?php echo htmlentities(lang('data_cate_count')); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-green"><?php echo htmlentities(lang('data_real')); ?></span>
                                                        <h5><?php echo htmlentities(lang('data_count_feed')); ?></h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo htmlentities($feed); ?></h1>
                                                        <small><?php echo htmlentities(lang('data_cate_count')); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-credit-card icon icon-blue"></i><?php echo htmlentities(lang('data_quick')); ?></div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10 layuimini-qiuck">
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/menu" data-title="<?php echo htmlentities(lang('back_menu')); ?>" data-icon="fa fa-window-maximize">
                                                <i class="fa fa-window-maximize"></i>
                                                <cite><?php echo htmlentities(lang('back_menu')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/system" data-title="<?php echo htmlentities(lang('configuration')); ?>" data-icon="fa fa-gears">
                                                <i class="fa fa-gears"></i>
                                                <cite><?php echo htmlentities(lang('configuration')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/article" data-title="<?php echo htmlentities(lang('article_manage')); ?>" data-icon="fa fa-file-text">
                                                <i class="fa fa-file-text"></i>
                                                <cite><?php echo htmlentities(lang('article_manage')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="/icon.html" data-title="<?php echo htmlentities(lang('icon_list')); ?>" data-icon="fa fa-dot-circle-o">
                                                <i class="fa fa-dot-circle-o"></i>
                                                <cite><?php echo htmlentities(lang('icon_list')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/category" data-title="<?php echo htmlentities(lang('article_cate')); ?>" data-icon="fa fa-calendar">
                                                <i class="fa fa-server"></i>
                                                <cite><?php echo htmlentities(lang('article_cate')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/visit" data-title="<?php echo htmlentities(lang('visit_list')); ?>" data-icon="fa fa-hourglass-end">
                                                <i class="fa fa-users"></i>
                                                <cite><?php echo htmlentities(lang('visit_list')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/feedback" data-title="<?php echo htmlentities(lang('feed_list')); ?>" data-icon="fa fa-snowflake-o">
                                                <i class="fa fa-comments"></i>
                                                <cite><?php echo htmlentities(lang('feed_list')); ?></cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="admin/link" data-title="<?php echo htmlentities(lang('link_list')); ?>" data-icon="fa fa-search">
                                                <i class="fa fa-link"></i>
                                                <cite><?php echo htmlentities(lang('link_list')); ?></cite>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="layui-col-md12">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-line-chart icon"></i><?php echo htmlentities(lang('report_count')); ?></div>
                            <div class="layui-card-body">
                                <div id="echarts-records" style="width: 100%;min-height:500px"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="layui-col-md4">
                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-bullhorn icon icon-tip"></i><?php echo htmlentities(lang('system_notice')); ?></div>
                    <div class="layui-card-body layui-text">
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title"><?php echo htmlentities(lang('access_control')); ?></div>
                            <div class="layuimini-notice-extra">2019-07-11 23:06</div>
                            <div class="layuimini-notice-content layui-hide">
                                界面足够简洁清爽。<br>
                                权限设置一目了然，无需复杂操作。<br>
                                支持多角色权限权限控制。<br>
                            </div>
                        </div>
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title"><?php echo htmlentities(lang('article_manage')); ?></div>
                            <div class="layuimini-notice-extra">2019-07-11 12:57</div>
                            <div class="layuimini-notice-content layui-hide">
                                界面足够简洁清爽。<br>
                                支持附件上传下载，控制下载权限。<br>
                                多站发布文章可同步，只需要配置好相关配置既可。<br>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-fire icon"></i><?php echo htmlentities(lang('version_info')); ?></div>
                    <div class="layui-card-body layui-text">
                        <table class="layui-table">
                            <colgroup>
                                <col width="130">
                                <col>
                            </colgroup>
                            <tbody>
                            <tr>
                                <td><?php echo htmlentities(lang('run_info')); ?></td>
                                <td>
                                    <?php 
                                    echo PHP_OS.'（'.$_SERVER['SERVER_SOFTWARE'].'）';
                                     ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('service_port')); ?></td>
                                <td><?php echo $_SERVER['HTTP_HOST'] ?></td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('upload_size_limit')); ?></td>
                                <td><?php echo get_cfg_var("file_uploads") ? get_cfg_var("upload_max_filesize") : '*'?></td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('system_name')); ?></td>
                                <td>
                                    MiniCMS
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('system_version')); ?></td>
                                <td>
                                    <span class="layui-btn layui-btn-danger layui-btn-xs"><?php echo htmlentities(config('version.code')); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('php_version')); ?></td>
                                <td>
                                    <?php 
                                    echo PHP_VERSION;
                                     ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('thinkphp_version')); ?></td>
                                <td><?php echo app()->version(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('mysql_version')); ?></td>
                                <td>
                                    <?php 
                                    echo $mysql;
                                     ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('main_features')); ?></td>
                                <td><?php echo htmlentities(lang('intro_thres')); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('demo_url')); ?></td>
                                <td>
                                    案例一：<a href="https://www.itmkk.com" target="_blank">点击查看</a><br>
                                    案例二：<a href="https://www.9wdn.com" target="_blank">点击查看</a><br>
                                </td>
                            </tr>
                            <tr>
                                <td><?php echo htmlentities(lang('down_url')); ?></td>
                                <td>
                                    <a href="https://gitee.com/cary10000/CyMini" target="_blank">gitee</a><br>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-paper-plane-o icon"></i><?php echo htmlentities(lang('develop_author')); ?></div>
                    <div class="layui-card-body layui-text layadmin-text">
                        <p>
                            <?php echo htmlentities(lang('system_desc')); ?>
                            <a class="layui-btn layui-btn-xs layui-btn-danger" target="_blank" href="https://gitee.com/cary10000/CyMini">仓库地址</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script src="/hyy1.0.0/lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="/hyy1.0.0/js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script src="/hyy1.0.0/js/public.js" charset="utf-8"></script>


<script>
    layui.use(['layer', 'miniTab','echarts'], function () {
        var $ = layui.jquery,
            layer = layui.layer,
            miniTab = layui.miniTab,
            echarts = layui.echarts;

        miniTab.listen();
        //触发事件
        var active = {
            OnlineUpdate: function(){
                //示范一个公告层
                layer.open({
                    type: 2
                    ,title: '系统更新中。。。' //不显示标题栏
                    ,shade: 0.8
                    ,moveType: 1 //拖拽模式，0或者1
                    ,area:[$(window).width()*0.9+'px',$(window).height() - 50+'px']
                    ,content: '<?php echo url("update/step1"); ?>'
                    ,success: function(layero){

                    }
                    ,end:function(){
                        //关闭弹窗，刷新页面
                        window.location.reload();
                    }
                });
            },
            UpdateSql: function(){
                //示范一个公告层
                layer.open({
                    type: 2
                    ,title: '数据库更新中。。。' //不显示标题栏
                    ,shade: 0.8
                    ,moveType: 1 //拖拽模式，0或者1
                    ,area:[$(window).width()*0.9+'px',$(window).height() - 50+'px']
                    ,content: '<?php echo url("update/step3"); ?>'
                    ,success: function(layero){

                    }
                    ,end:function(){
                        //关闭弹窗，刷新页面
                        window.location.reload();
                    }
                });
            },
        };

        $('#layerDemo a').on('click', function(){
            var othis = $(this), method = othis.data('method');
            active[method] ? active[method].call(this, othis) : '';
        });
        /**
         * 查看公告信息
         **/
        $('body').on('click', '.layuimini-notice', function () {
            var title = $(this).children('.layuimini-notice-title').text(),
                noticeTime = $(this).children('.layuimini-notice-extra').text(),
                content = $(this).children('.layuimini-notice-content').html();
            var html = '<div style="padding:15px 20px; text-align:justify; line-height: 22px;border-bottom:1px solid #e2e2e2;background-color: #2f4056;color: #ffffff">\n' +
                '<div style="text-align: center;margin-bottom: 20px;font-weight: bold;border-bottom:1px solid #718fb5;padding-bottom: 5px"><h4 class="text-danger">' + title + '</h4></div>\n' +
                '<div style="font-size: 12px">' + content + '</div>\n' +
                '</div>\n';
            parent.layer.open({
                type: 1,
                title: '系统公告'+'<span style="float: right;right: 1px;font-size: 12px;color: #b1b3b9;margin-top: 1px">'+noticeTime+'</span>',
                area: '300px;',
                shade: 0.8,
                shadeClose:true,
                id: 'layuimini-notice',
                btn: ['查看', '取消'],
                btnAlign: 'c',
                moveType: 1,
                content:html,
                success: function (layero) {
                    var btn = layero.find('.layui-layer-btn');
                    btn.find('.layui-layer-btn0').attr({
                        href: 'https://gitee.com/cary10000/tp8admin',
                        target: '_blank'
                    });
                }
            });
        });

        /**
         * 报表功能
         */
        var echartsRecords = echarts.init(document.getElementById('echarts-records'), 'walden');
        var optionRecords = {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data:['邮件营销','联盟广告','视频广告','直接访问','搜索引擎']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['周一','周二','周三','周四','周五','周六','周日']
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name:'邮件营销',
                    type:'line',
                    data:[120, 132, 101, 134, 90, 230, 210]
                },
                {
                    name:'联盟广告',
                    type:'line',
                    data:[220, 182, 191, 234, 290, 330, 310]
                },
                {
                    name:'视频广告',
                    type:'line',
                    data:[150, 232, 201, 154, 190, 330, 410]
                },
                {
                    name:'直接访问',
                    type:'line',
                    data:[320, 332, 301, 334, 390, 330, 320]
                },
                {
                    name:'搜索引擎',
                    type:'line',
                    data:[820, 932, 901, 934, 1290, 1330, 1320]
                }
            ]
        };
        echartsRecords.setOption(optionRecords);

        // echarts 窗口缩放自适应
        window.onresize = function(){
            echartsRecords.resize();
        }

    });
</script>
</body>
</html>
