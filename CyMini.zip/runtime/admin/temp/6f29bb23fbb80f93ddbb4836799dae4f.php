<?php /*a:3:{s:44:"D:\web\tp\tp8\app\admin\view\tags\index.html";i:1721154149;s:49:"D:\web\tp\tp8\app\admin\view\public\file_css.html";i:1702992266;s:48:"D:\web\tp\tp8\app\admin\view\public\file_js.html";i:1703250444;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlentities(lang('BackMenu')); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/hyy1.0.0/lib/layui-v2.6.3/css/layui.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0//lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/imgUp.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/public.css" media="all">

    <style>
        .layui-btn:not(.layui-btn-lg ):not(.layui-btn-sm):not(.layui-btn-xs) {
            height: 34px;
            line-height: 34px;
            padding: 0 8px;
        }
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <fieldset style="display: none;" id="inputSearch" class="table-search-fieldset">
            <legend><?php echo htmlentities(lang('search_info')); ?></legend>
            <div style="margin: 10px 10px 10px 10px">
                <form id="searchData" lay-filter="searchData" onsubmit="return false;" class="layui-form layui-form-pane">
                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <label class="layui-form-label"><?php echo htmlentities(lang('tags')); ?></label>
                            <div class="layui-input-inline">
                                <input type="text" name="tag" autocomplete="off" class="layui-input">
                            </div>
                        </div>
                        <div class="layui-inline">
                            <button type="submit" class="layui-btn layui-btn-primary" id="doSearch" lay-submit lay-filter="doSearch""><i class="layui-icon"></i>
                            <?php echo htmlentities(lang('search')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </fieldset>
        <!--头部工具栏-->
        <div id="toolbarDemo" style="display: none;background: #fff;">
            <span id="AddUrl" alt="<?php echo url('add'); ?>" style="display: none"></span>
            <button class="layui-btn layui-btn-normal layui-btn-sm" lay-event="adds">
                <i class="fa fa-plus"></i> <?php echo htmlentities(lang('add')); ?>
            </button>
            <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="delete"> <?php echo htmlentities(lang('batchDel')); ?> </button>
        </div>
        <!--数据表格-->
        <table class="layui-hide" id="DataDemos" lay-filter="DataDemos"></table>

        <!-- 操作列 -->
        <script type="text/html" id="toolBar">
            <span id="ActionUrl" alt="<?php echo url('add'); ?>" title="<?php echo htmlentities(lang('view')); ?>" style="display: none"></span>
            <span id="DelUrl" alt="<?php echo url('delAll'); ?>" style="display: none"></span>
            <span id="FieldUrl" alt="<?php echo url('updateField'); ?>" style="display: none"></span>
            <button class="layui-btn layui-btn-xs" lay-event="edits"><?php echo htmlentities(lang('edit')); ?></button>
            <button class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo htmlentities(lang('del')); ?></button>
        </script>

    </div>
</div>

<script src="/hyy1.0.0/lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="/hyy1.0.0/js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script src="/hyy1.0.0/js/public.js" charset="utf-8"></script>

<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;

        table.render({
            elem: '#DataDemos',
            url: '<?php echo url("datalist"); ?>',
            toolbar: '#toolbarDemo',
            method: 'get',
            page: true,  //开启分页
            limit: 10,  //默认10条
            height: '550', // 最大高度减去其他容器已占有的高度差
            defaultToolbar: ['filter', 'exports', 'print', {
                title: '<?php echo htmlentities(lang('search')); ?>',
                layEvent: 'laySearch',
                icon: 'layui-icon layui-icon-search'
            }],
            cols: [[
                {type: "checkbox", width: 50},
                {field: 'id', align:"center", width: 80, title: 'ID', sort: true},
                {field: 'name',width:160, align: 'center',title: '<?php echo htmlentities(lang('category')); ?>'},
                {field: 'tag', align: 'center',title: '<?php echo htmlentities(lang('tags')); ?>'},
                {field: 'ArCount',width:160, align: 'center',title: '<?php echo htmlentities(lang('ArCount')); ?>'},
                {field: 'createTime',width:200, align: 'center',title: '<?php echo htmlentities(lang('createTime')); ?>'},
                {fixed:'right',title: '<?php echo htmlentities(lang('operate')); ?>', width: 120, toolbar: '#toolBar', align: "center"}
            ]],
        });
    });
</script>
</body>
</html>