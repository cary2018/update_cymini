<?php /*a:3:{s:47:"D:\web\tp\tp8\app\admin\view\article\index.html";i:1721154903;s:49:"D:\web\tp\tp8\app\admin\view\public\file_css.html";i:1702992266;s:48:"D:\web\tp\tp8\app\admin\view\public\file_js.html";i:1703250444;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities(lang('admin')); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/hyy1.0.0/lib/layui-v2.6.3/css/layui.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0//lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/imgUp.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/public.css" media="all">

    <style type="text/css">
        .layui-table-cell{
            text-align:center;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
        }
        .layui-table img{
            max-width:100%
        }
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <fieldset style="display: none;" id="inputSearch" class="table-search-fieldset">
            <legend><?php echo htmlentities(lang('search_info')); ?></legend>
            <div style="margin: 10px 10px 10px 10px">
                <form id="searchData" lay-filter="searchData" onsubmit="return false;" class="layui-form layui-form-pane">
                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <div class="layui-input-inline">
                                <input type="text" name="title" placeholder="<?php echo htmlentities(lang('variable_title')); ?>" autocomplete="off" class="layui-input">
                            </div>

                            <div class="layui-input-inline">
                                <select name="status" layui.formselect>
                                    <option value=""><?php echo htmlentities(lang('DownSelect')); ?></option>
                                    <?php foreach($read as $key=>$vo): ?>
                                    <option value="<?php echo htmlentities($key); ?>" ><?php echo htmlentities($vo); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="layui-input-inline">
                                <select name="cid" layui.formselect>
                                    <option value=""><?php echo htmlentities(lang('DownSelect')); ?></option>
                                    <?php if(is_array($tree) || $tree instanceof \think\Collection || $tree instanceof \think\Paginator): $i = 0; $__LIST__ = $tree;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
                                    <option value="<?php echo htmlentities($item['id']); ?>" ><?php echo $item['p']; ?><?php echo htmlentities($item['name']); ?></option>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="layui-inline">
                            <button type="submit" class="layui-btn layui-btn-primary" id="doSearch" lay-submit lay-filter="doSearch""><i class="layui-icon"></i>
                            <?php echo htmlentities(lang('search')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </fieldset>

        <!--头部工具栏-->
        <div id="toolbarDemo" style="display: none;background: #fff;">
            <span id="FieldUrl" alt="<?php echo url('updateField'); ?>" style="display: none"></span>
            <span id="SwitchUrl" alt="<?php echo url('switchAt'); ?>" style="display: none"></span>
            <span id="AddUrl" alt="<?php echo url('add'); ?>" style="display: none"></span>
            <button class="layui-btn layui-btn-normal layui-btn-sm data-add-btn" lay-event="adds"> <?php echo htmlentities(lang('add')); ?> </button>
            <button class="layui-btn layui-btn-sm layui-btn-danger data-delete-btn" lay-event="delete"> <?php echo htmlentities(lang('batchDel')); ?> </button>
        </div>
        <!--数据-->
        <table class="layui-hide" id="DataDemos" lay-filter="DataDemos"></table>
        <!--操作-->
        <script type="text/html" id="toolBar">
            <span id="DelUrl" alt="<?php echo url('delAll'); ?>" style="display: none"></span>
            <span id="ActionUrl" alt="<?php echo url('edit'); ?>" style="display: none"></span>
            <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edits"><?php echo htmlentities(lang('edit')); ?></a>
            <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo htmlentities(lang('del')); ?></a>
        </script>

    </div>
</div>
<script src="/hyy1.0.0/lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="/hyy1.0.0/js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script src="/hyy1.0.0/js/public.js" charset="utf-8"></script>

<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;

        table.render({
            elem: '#DataDemos',
            url: '<?php echo url("dataList"); ?>',
            toolbar: '#toolbarDemo',
            method: 'get',
            page: true,  //开启分页
            limit: 10,  //默认10条
            height: '550', // 最大高度减去其他容器已占有的高度差
            defaultToolbar: ['filter', 'exports', 'print', {
                title: '<?php echo htmlentities(lang('search')); ?>',
                layEvent: 'laySearch',
                icon: 'layui-icon layui-icon-search'
            }],
            cols: [[
                {type: "checkbox", width: 50},
                {field: 'id', align:"center", width: 80, title: 'ID', sort: true},
                {field: 'title', align: 'center',edit:true,title: '<?php echo htmlentities(lang('variable_title')); ?>'},
                {field: 'nickname', align: 'center',width:100,title: '<?php echo htmlentities(lang('category')); ?>'},
                {field: 'articleThumbImg', align: 'center',width:80,title: '<?php echo htmlentities(lang('articleImg')); ?>',templet:function (d) {
                        if(d.articleThumbImg){
                            return '<img id="imgAmplify" title="'+d.title+'" layer-src="/'+d.articleImg+'" src="/'+d.articleThumbImg+'"/>';
                        }else{
                            return '';
                        }
                    }},
                {field: 'orderSort', align: 'center',width:80,edit:true,title: '<?php echo htmlentities(lang('orderSort')); ?>'},
                {field: 'views', align: 'center',width:80,title: '<?php echo htmlentities(lang('views')); ?>'},
                {field: 'createTime', align: 'center',title: '<?php echo htmlentities(lang('createTime')); ?>'},
                {
                    field: 'status', width: 120, align: 'center', templet: function (d) {
                        if (d.status == 1) {
                            return '<input type="checkbox" name="status" value="'+d.id+'" lay-skin="switch" lay-filter="switchTest" lay-text="'+d.status2+'|'+d.status1+'" checked> ';
                        } else {
                            return '<input type="checkbox" name="status" value="'+d.id+'" lay-skin="switch" lay-filter="switchTest" lay-text="'+d.status2+'|'+d.status1+'"> ';
                        }
                    }, title: '<?php echo htmlentities(lang('status')); ?>'
                },
                {
                    field: 'downloadJur', width: 100, align: 'center', templet: function (d) {
                        if (d.downloadJur == 1) {
                            return '<input type="checkbox" name="downloadJur" value="'+d.id+'" lay-skin="switch" lay-filter="switchTest" lay-text="<?php echo htmlentities(lang('public')); ?>|<?php echo htmlentities(lang('private')); ?>" checked> ';
                        } else {
                            return '<input type="checkbox" name="downloadJur" value="'+d.id+'" lay-skin="switch" lay-filter="switchTest" lay-text="<?php echo htmlentities(lang('public')); ?>|<?php echo htmlentities(lang('private')); ?>"> ';
                        }
                    }, title: '<?php echo htmlentities(lang('downloadJur')); ?>'
                },

                {fixed:'right',title: '<?php echo htmlentities(lang('operate')); ?>', width: 120, toolbar: '#toolBar', align: "center"}
            ]],
        });
    });
</script>

</body>
</html>