<?php /*a:3:{s:45:"D:\web\tp\tp8\app\admin\view\system\list.html";i:1721153648;s:49:"D:\web\tp\tp8\app\admin\view\public\file_css.html";i:1702992266;s:48:"D:\web\tp\tp8\app\admin\view\public\file_js.html";i:1703250444;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlentities(lang('BackMenu')); ?></title>
    <link rel="stylesheet" href="/hyy1.0.0/lib/layui-v2.6.3/css/layui.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0//lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/imgUp.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/public.css" media="all">

    <style>
        .layui-btn:not(.layui-btn-lg ):not(.layui-btn-sm):not(.layui-btn-xs) {
            height: 34px;
            line-height: 34px;
            padding: 0 8px;
        }
    </style>
</head>
<body>
<div class="layuimini-container">
    <div id="saveOrUpdate" style="display: none;">
        66666
    </div>
    <div class="layuimini-main">
        <div>
            <div class="layui-btn-group">
                <button class="layui-btn" id="btn-expand"><?php echo htmlentities(lang('allExpand')); ?></button>
                <button class="layui-btn layui-btn-normal" id="btn-fold"><?php echo htmlentities(lang('allFold')); ?></button>
                <button class="layui-btn layui-btn-warm" id="btn-reload">
                    <i class="fa fa-refresh"></i>
                </button>
            </div>
            <!--头部工具栏-->
            <div id="toolbarDemo" style="display: none;background: #fff;">
                <span id="SwitchUrl" alt="<?php echo url('system/switchAt'); ?>" style="display: none"></span>
                <span id="AddUrl" alt="<?php echo url('system/add'); ?>" style="display: none"></span>
                <a href="#" class="layui-btn " lay-event="adds"><i class="fa fa-plus"></i> <?php echo htmlentities(lang('add')); ?></a>
            </div>
            <!--数据表格-->
            <table class="layui-hide" id="DataDemos" lay-filter="DataDemos"></table>
        </div>
    </div>
</div>
<!-- 操作列 -->
<script type="text/html" id="toolBar">
    <span id="ActionUrl" alt="<?php echo url('edit'); ?>" style="display: none"></span>
    <span id="DelUrl" alt="<?php echo url('delAll'); ?>" style="display: none"></span>
    <span id="FieldUrl" alt="<?php echo url('updateField'); ?>" style="display: none"></span>
    <span id="JumpUrl" alt="<?php echo url('add'); ?>" style="display: none"></span>
    <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="product"><?php echo htmlentities(lang('AddSub')); ?></a>
    <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edits"><?php echo htmlentities(lang('edit')); ?></a>
    <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo htmlentities(lang('del')); ?></a>
</script>

<script src="/hyy1.0.0/lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="/hyy1.0.0/js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script src="/hyy1.0.0/js/public.js" charset="utf-8"></script>

<script>
    layui.use(['table','treetable'], function () {
        var $ = layui.jquery;
        var treetable = layui.treetable;

        // 渲染表格
        layer.load(2);
        var treeIns = function () {
            layer.load(2);
            treetable.render({
                treeColIndex: 1,
                treeSpid: 0,
                treeIdName: 'id',
                treePidName: 'pid',
                elem: '#DataDemos',
                toolbar: '#toolbarDemo', //开启头部工具栏，并为其绑定左侧模板
                url: '<?php echo url("dataList"); ?>',
                defaultToolbar: ['filter', 'exports', 'print', {
                    title: '<?php echo htmlentities(lang('search')); ?>',
                    layEvent: 'LAYTABLE_TIPS',
                    icon: 'layui-icon layui-icon-search'
                }],
                page: false,
                cols: [[
                    {type: 'numbers'},
                    {field: 'sys_title', minWidth: 200, title: '<?php echo htmlentities(lang('variable_title')); ?>'},
                    {field: 'sys_variable', minWidth: 120, align: 'center',title: '<?php echo htmlentities(lang('variable_name')); ?>'},
                    {field: 'sys_content', title: '<?php echo htmlentities(lang('variable_value')); ?>',edit:'true'},
                    {field: 'sys_remark', title: '<?php echo htmlentities(lang('remark')); ?>',edit:'true'},
                    {field: 'sys_order', width: 80, align: 'center',edit:true, title: '<?php echo htmlentities(lang('OrderSort')); ?>'},
                    {templet: '#toolBar', width: 190, align: 'center', title: '<?php echo htmlentities(lang('operate')); ?>'}
                ]],
                done: function () {
                    layer.closeAll('loading');
                }
            });
        }

        $('#btn-expand').click(function () {
            treetable.expandAll('#DataDemos');
        });

        $('#btn-fold').click(function () {
            treetable.foldAll('#DataDemos');
        });
        //重载数据表格
        treeIns();
        $('#btn-reload').click(function () {
            treeIns();
        });
    });
</script>
</body>
</html>