<?php /*a:3:{s:46:"D:\web\tp\tp8\app\admin\view\system\index.html";i:1721415717;s:49:"D:\web\tp\tp8\app\admin\view\public\file_css.html";i:1702992266;s:48:"D:\web\tp\tp8\app\admin\view\public\file_js.html";i:1703250444;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlentities(lang('admin')); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/hyy1.0.0/lib/layui-v2.6.3/css/layui.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0//lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/imgUp.css" media="all">
<link rel="stylesheet" href="/hyy1.0.0/css/public.css" media="all">

    <style type="text/css">
        .layui-table img{
            text-align:center;
            height: auto;
            white-space: normal;
            max-width: 50px;
        }
    </style>
</head>
<body>
<div class="layuimini-container">
    <fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
        <legend>
            <a href="#" class="layui-btn " id="adds" alt="<?php echo url('add'); ?>">
                <i class="fa fa-edit"></i> <?php echo htmlentities(lang('add')); ?>
            </a>
        </legend>
    </fieldset>

    <div class="layui-tab layui-tab-brief">
        <ul class="layui-tab-title">
            <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $k = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($k % 2 );++$k;if($k==1): ?>
                    <li class="layui-this"><?php echo htmlentities($item['sys_title']); ?></li>
                <?php else: ?>
                    <li><?php echo htmlentities($item['sys_title']); ?></li>
                <?php endif; ?>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="layui-tab-content">
                <span id="ActionUrl" alt="<?php echo url('batchSave'); ?>"></span>
                <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $k = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($k % 2 );++$k;if($k==1): ?>
                        <div class="layui-tab-item layui-show">
                            <form id="DataForm" lay-filter="DataForm" onsubmit="return false">
                                <table class="layui-table layui-form">
                                    <thead>
                                        <tr>
                                            <td><?php echo htmlentities(lang('variable_title')); ?></td>
                                            <td><?php echo htmlentities(lang('variable_name')); ?></td>
                                            <td><?php echo htmlentities(lang('variable_value')); ?></td>
                                            <td><?php echo htmlentities(lang('Remark')); ?></td>
                                            <td><?php echo htmlentities(lang('operate')); ?></td>
                                        </tr>
                                    </thead>
                                    <?php if(is_array($item['son']) || $item['son'] instanceof \think\Collection || $item['son'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['son'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                        <tr>
                                            <td><?php echo htmlentities($v['sys_title']); ?></td>
                                            <td><?php echo htmlentities($v['sys_variable']); ?></td>
                                            <td>
                                                <input type="hidden" id="id" name="id[]" value="<?php echo htmlentities($v['id']); ?>">
                                                <?php echo $v['sys_html']; ?>
                                            </td>
                                            <td><?php echo htmlentities($v['sys_remark']); ?></td>
                                            <td>
                                                <a class="layui-btn layui-btn-normal layui-btn-sm" alt="<?php echo url('edit'); ?>?id=<?php echo htmlentities($v['id']); ?>" lay-submit lay-filter="save"><?php echo htmlentities(lang('edit')); ?></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </table>
                                <div class="layui-form-item">
                                    <div class="layui-input-block">
                                        <button class="layui-btn layui-btn-normal" lay-submit lay-filter="doSubmit"><?php echo htmlentities(lang('Save')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="layui-tab-item">
                            <form id="DataForm<?php echo htmlentities($k); ?>" lay-filter="DataForm<?php echo htmlentities($k); ?>" onsubmit="return false">
                                <table class="layui-table layui-form">
                                    <thead>
                                        <tr>
                                            <td><?php echo htmlentities(lang('variable_title')); ?></td>
                                            <td><?php echo htmlentities(lang('variable_name')); ?></td>
                                            <td><?php echo htmlentities(lang('variable_value')); ?></td>
                                            <td><?php echo htmlentities(lang('Remark')); ?></td>
                                            <td><?php echo htmlentities(lang('operate')); ?></td>
                                        </tr>
                                    </thead>
                                    <?php if(is_array($item['son']) || $item['son'] instanceof \think\Collection || $item['son'] instanceof \think\Paginator): $i = 0; $__LIST__ = $item['son'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                        <tr>
                                            <td><?php echo htmlentities($v['sys_title']); ?></td>
                                            <td><?php echo htmlentities($v['sys_variable']); ?></td>
                                            <td>
                                                <input type="hidden" name="id[]" value="<?php echo htmlentities($v['id']); ?>">
                                                <?php echo $v['sys_html']; ?>
                                            </td>
                                            <td><?php echo htmlentities($v['sys_remark']); ?></td>
                                            <td>
                                                <a class="layui-btn layui-btn-normal layui-btn-sm" alt="<?php echo url('edit'); ?>?id=<?php echo htmlentities($v['id']); ?>" lay-submit lay-filter="save"><?php echo htmlentities(lang('edit')); ?></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>

                                </table>
                                <div class="layui-form-item">
                                    <div class="layui-input-block">
                                        <button class="layui-btn layui-btn-normal" lay-submit lay-filter="doSubmit"><?php echo htmlentities(lang('Save')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endforeach; endif; else: echo "" ;endif; ?>

        </div>
    </div>
</div>
<script src="/hyy1.0.0/lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="/hyy1.0.0/js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script src="/hyy1.0.0/js/public.js" charset="utf-8"></script>

<script>
    layui.use(['table','form'], function () {
        var $ = layui.jquery;
        var form = layui.form;
        var table = layui.table;

        //添加、编辑
        $('#adds').click(function () {
            let JumpUrls = $('#adds').attr('alt');
            if(JumpUrls == ''){
                JumpUrls = 'add';
            }
            parent.layer.open({
                type:2,
                title:'信息',
                content:JumpUrls,
                shadeClose: true,
                maxmin:true,
                area:[$(window).width()*0.9+'px',$(window).height() - 50+'px']
            });
        });
    });
</script>
</body>
</html>