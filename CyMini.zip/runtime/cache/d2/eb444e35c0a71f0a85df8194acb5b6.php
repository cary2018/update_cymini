<?php
//000388800000
 exit();?>
a:5:{i:0;a:5:{s:2:"id";i:5;s:4:"code";s:1:"j";s:7:"remarks";s:6:"加粗";s:9:"orderSort";i:100;s:6:"status";i:1;}i:1;a:5:{s:2:"id";i:4;s:4:"code";s:1:"t";s:7:"remarks";s:6:"特荐";s:9:"orderSort";i:100;s:6:"status";i:1;}i:2;a:5:{s:2:"id";i:3;s:4:"code";s:1:"a";s:7:"remarks";s:6:"头条";s:9:"orderSort";i:100;s:6:"status";i:1;}i:3;a:5:{s:2:"id";i:2;s:4:"code";s:1:"h";s:7:"remarks";s:6:"热门";s:9:"orderSort";i:100;s:6:"status";i:1;}i:4;a:5:{s:2:"id";i:1;s:4:"code";s:1:"c";s:7:"remarks";s:6:"推荐";s:9:"orderSort";i:100;s:6:"status";i:1;}}