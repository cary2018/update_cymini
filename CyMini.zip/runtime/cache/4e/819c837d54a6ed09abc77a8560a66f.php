<?php
//000000000000
 exit();?>
a:2:{s:8:"testhook";a:1:{i:0;a:2:{i:0;s:19:"\addons\test\Plugin";i:1;s:8:"testhook";}}s:4:"show";a:1:{i:0;a:2:{i:0;s:19:"\addons\test\Plugin";i:1;s:4:"show";}}}