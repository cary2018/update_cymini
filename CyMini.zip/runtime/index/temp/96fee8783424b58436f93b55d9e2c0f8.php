<?php /*a:7:{s:34:"template/default/detail\index.html";i:1720674868;s:36:"template/default/layout\file-js.html";i:1719637054;s:39:"template/default/layout\file-style.html";i:1719637134;s:33:"template/default/layout\icon.html";i:1719636551;s:36:"template/default/layout\navmenu.html";i:1720674868;s:39:"template/default/layout\list-right.html";i:1720674868;s:35:"template/default/layout\footer.html";i:1718957421;}*/ ?>
<!DOCTYPE html>
<html xml:lang="zh-Hans" lang="zh-Hans" style="transform: none;">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="applicable-device" content="pc,mobile" />
    <meta name="renderer" content="webkit" />
    <meta name="force-rendering" content="webkit" />
    <title><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["title"];} ?> - <?php echo htmlentities(config('web.web_title')); ?></title>
    <meta name="keywords" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["keywords"];} ?>" />
    <meta name="description" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["description"];} ?>" />
    <meta name="author" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["author"];} ?>" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["title"];} ?>" />
    <meta property="og:description" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["description"];} ?>" />
    <meta property="og:url" content="https://www.itmkk.com" />
    <meta property="og:release_date" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["createTime"];} ?>" />
    <meta property="og:updated_time" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["createTime"];} ?>" />
    <meta property="og:article:author" content="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["author"];} ?>" />

    <script src="/template/default/static/js/jquery.min-3.6.1.js"></script>
<script src="/template/default/static/js/zblogphp.js"></script>
<script src="/template/default/static/js/c_html_js_add.js"></script>
    <link rel="stylesheet" href="/template/default/static/css/style.css" type="text/css" media="all" as="style" />
<link rel="stylesheet" href="/template/default/static/css/public.css" type="text/css" media="all" />

    <script src="/template/conme/static/layui/layui.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="/template/conme/static/layui/css/layui.css" />

    <link rel="stylesheet" href="/template/default/static/css/animate.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/template/default/static/css/night.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/template/default/static/css/fancybox.css" type="text/css" media="all" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

    <!--[if lt IE 9]><script src="https://cdn.staticfile.org/html5shiv/3.7.0/html5shiv.js"></script><![endif]-->

</head>
<body class="home home-article" style="transform: none;">


<header class="top-header">
    <div class="top-bar fixed-nav fixed-appear">
        <div class="container secnav secnav-b clearfix">
            <div class="fav-subnav">
                <div class="top-bar-left pull-left navlogo">
                    <div class="m-top-search">
                        <i class="icon font-search top-search"></i>
                    </div>
                    <a href="/" class="logo" title="...">
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-light" id="logo-light" alt="..." />
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-dark d-none" id="logo-dark" alt="..." />
                        <b class="shan"></b>
                    </a>
                    <div class="m-top-logo">
                        <i class="nav-bar"><span></span><span></span><span></span></i>
                    </div>
                </div>
                <div class="top-nav-left header-nav fl" data-type="index" data-infoid="index">
                    <aside class="mobile_aside mobile_nav">
                        <ul id="nav" class="top-bar-menu nav-pills">
                            <li id="nvabar-item-index">
                                <a href="/">
                                    <i class="icon font-home"></i>
                                    首页
                                </a>
                            </li>
                            <?php $__navmenu__ = GetCache('NavMenu');$__LIST__ = $__navmenu__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                            <li id="navbar-category-<?php echo htmlentities($vo['id']); ?>" class="<?php if($vo['son']): ?>menu-item-has-children<?php endif; ?>">
                                <a href="<?php echo !empty($vo['isUrl']) ? htmlentities($vo['outUrl']) : htmlentities($vo['temp_list']); ?>?id=<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                    <i class="icon <?php echo htmlentities($vo['iconfont']); ?>"></i>
                                    <?php echo htmlentities($vo['name']); ?>
                                </a>
                                <?php if($vo['son']): ?>
                                <span class="toggle-btn"><i class="icon font-chevron-down"></i></span>
                                <ul class="dropdown-menu sub-menu">
                                    <?php foreach($vo['son'] as $skey=>$item): ?>
                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                                        <a href="<?php echo !empty($item['isUrl']) ? htmlentities($item['outUrl']) : htmlentities($item['temp_list']); ?>?id=<?php echo htmlentities($item['id']); ?>" target="<?php echo htmlentities($item['target']); ?>">
                                            <?php echo htmlentities($item['name']); ?>
                                        </a>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </aside>
                    <div id="mask"></div>
                </div>
                <div class="search-warp clearfix">
                    <div class="search_top">
                        <div class="search-icon"></div>
                        <div class="search-box">
                            <form name="search" method="get" action="/index/search">
                                <input class="search-input" value="<?php echo app('request')->param('q')?app('request')->param('q'):''; ?>" placeholder="请输入关键字" type="text" name="q" />
                                <button class="showhide-search" type="submit">搜 索</button>
                                <span class="s-icon"></span>
                            </form>
                        </div>
                    </div>
                    <a class="at-night top-night" title="夜间模式" href="javascript:switchNightMode()" target="_self"></a>
                    <a class="top-tnrt" title="繁简转换" href="javascript:translatePage();" id="zh_tw">繁体</a>
                    <!--<div class="text-user-r">
                        <a target="_self" class="t-btn r-btn-ht" title="HI，您好！" href="javascript:lcp.loginPopup('register');">注册</a>
                        <a target="_self" class="t-btn l-btn-ht" title="登录账户" href="javascript:lcp.loginPopup();">登录</a>
                    </div>-->
                </div>
            </div>
        </div>
        <div id="percentageCounter" style="width: 0%;"></div>
    </div>
</header>


<main class="main-content container clearfix" style="transform: none; height: auto !important;">
    <div class="row" style="transform: none; height: auto !important;">
        <div class="main fl" style="height: auto !important;">
            <div class="single box-show" style="height: auto !important;">
                <article class="single-post" style="height: auto !important;">
                    <header class="single-title">
                        <nav class="single-place place">
                            <i class="icon font-home"></i>
                            <a href="/">首页</a>
                            <?php $__Breadcrumb__ = Breadcrumb($__detail__["cid"]);$__LIST__ = $__Breadcrumb__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                            <i class="icon font-angle-right"></i>
                            <a href="<?php echo !empty($vo['isUrl']) ? htmlentities($vo['outUrl']) : htmlentities($vo['temp_list']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="查看 <?php echo htmlentities($vo['name']); ?> 分类中的全部文章"><?php echo htmlentities($vo['name']); ?></a>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                            <i class="icon font-angle-right"></i>
                            <a href="javascript:;" rel="bookmark" title="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["title"];} ?>">正文</a>
                        </nav>
                        <div id="font-change" class="single-font fr">
                            <span id="font-dec"><a href="#" title="减小字体"><i class="icon font-minus-square-o"></i></a></span>
                            <span id="font-int"><a href="#" title="默认字体"><i class="icon font-font"></i></a></span>
                            <span id="font-inc"><a href="#" title="增大字体"><i class="icon font-plus-square-o"></i></a></span>
                        </div>
                        <h1><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["title"];} ?></h1>
                        <div class="single-title-meta">
                            <span class="single-author"><a href="javascript:;" title="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["author"];} ?>"><i class="icon font-user-o"></i><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["author"];} ?></a></span>
                            <span class="single-time" title="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["createTime"];} ?>"><span class="spot"></span><i class="icon font-time"></i><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["createTime"];} ?></span>
                            <span class="single-views"><span class="spot"></span><i class="icon font-eye"></i><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["views"];} ?> 阅读</span>
                            <span class="single-comment"><span class="spot"></span><i class="icon font-comment"></i><a href="#comments"><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["feed"];} ?>评论</a></span>
                        </div>
                    </header>

                    <div class="single-entry">
                        <div id="post-body-888888" class="commdisplay_ajax auto-list">
                            <?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["content"];} ?>
                        </div>
                    </div>

                </article>
            </div>
            <div class="entry-next-prev wow fadeInDown " style="visibility: hidden; animation-name: none;">
                <?php $__next__ = FindTable("article",[["status","=",1],["cid","=",$__detail__["cid"]],["id",">",request()->param('id')]],["id"=>"asc"]);$__cate__ = FindTable("category",[["id","=",$__detail__["cid"]],["isShow","=",1]]);if($__next__){ $__next__["temp_archives"] = $__cate__["temp_archives"]; }if($__next__){ $pare = array(0=>$__next__);}else{ $pare = array();}$__LIST__ = $pare; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <p class="m-page-up fl">
                    <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" rel="prev"><?php echo htmlentities($vo['title']); ?></a>
                </p>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <a href="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["temp_list"];} ?>?id=<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["cid"];} ?>" class="u-back-list fl"><i class="返回栏目"></i></a>
                <?php $__next__ = FindTable("article",[["status","=",1],["cid","=",$__detail__["cid"]],["id","<",request()->param('id')]],["id"=>"desc"]);$__cate__ = FindTable("category",[["id","=",$__detail__["cid"]],["isShow","=",1]]);if($__next__){ $__next__["temp_archives"] = $__cate__["temp_archives"]; }if($__next__){ $pare = array(0=>$__next__);}else{ $pare = array();}$__LIST__ = $pare; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <p class="m-page-down fl">
                    <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" rel="next"><?php echo htmlentities($vo['title']); ?></a>
                </p>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <div class="clear"></div>
            </div>
            <div class="part-mor box-show wow fadeInDown liblog_ee997_73ca5" style="visibility: visible; animation-name: fadeInDown;">
                <!--相关文章-->
                <h3 class="section-title"><span>相关阅读</span></h3>
                <div class="pic-box-list pic-box-img clearfix liblog_c9363_78bde">
                    <!--相关分类-->
                    <?php $__article__ = Article($__detail__["cid"],"id",8,0);$__total__ = $__article__["__total__"];$__LIST__ = $__article__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                    <article class="sell-lia-item wow fadeInDown" style="visibility: hidden; animation-name: none;">
                        <div class="sell-pic-media">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" style="background-image:url(/<?php echo htmlentities($vo['articleThumbImg']); ?>);" target="<?php echo htmlentities($vo['target']); ?>">
                                <span class="pic-overlay"></span>
                            </a>
                        </div>
                        <div class="sell-media-t">
                            <h4 href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                    <?php echo htmlentities($vo['title']); ?>
                                </a>
                            </h4>
                        </div>
                    </article>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <section id="comments" class="box-show wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
                <div id="comt-respond" class="commentpost">
                    <h4>发表评论<span><a rel="nofollow" id="cancel-reply" href="#comment" style="display:none;"><small>取消回复</small></a></span></h4>
                    <form id="frmSumbit" target="_self" method="post" action="" onsubmit="return false;">
                        <input type="hidden" name="aid" id="inpId" value="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["id"];} ?>">
                        <input type="hidden" name="rid" id="inpRevID" value="0">
                        <input type="hidden" name="cid" value="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["cid"];} ?>">
                        <input type="hidden" name="article" value="<?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["title"];} ?>">
                        <input type="hidden" value="<?php echo token(); ?>" name="__token__" id="inpRevToken" >
                        <div class="comt-box">
                            <div class="form-group liuyan form-name">
                                <input type="text" name="username" id="inpName" class="text" value="" placeholder="昵称" size="28" tabindex="1" />
                            </div>
                            <div class="form-group liuyan form-email">
                                <input type="text" name="email" id="inpEmail" class="text" value="" placeholder="邮箱" size="28" tabindex="2" />
                            </div>
                            <div class="form-group liuyan form-www">
                                <input type="text" name="captcha" style="width:50%;float:left;" id="inpHomePage" class="text" value="" placeholder="验证码" size="28" tabindex="3">
                                <a><img style="line-height:44px;height:44px;max-height:44px;width:50%;" id="refreshCaptcha" onclick="this.src=this.src.replace(/\?.*$/, '')+'?'+Math.random()" class="validateImg" src="<?php echo captcha_src(); ?>" ></a>
                            </div>
                        </div>
                        <!--verify-->
                        <div class="liblog_ad6a5_0ec0e" id="comment-tools">
                            <div class="tools_text">
                                <textarea placeholder="请遵守相关法律与法规，文明评论。O(∩_∩)O~~" name="msg" id="txaArticle" class="text input-block-level comt-area" cols="50" rows="4" tabindex="5"></textarea>
                            </div>
                        </div>
                        <div class="psumbit inpVerify">
                            <div class="tools_title">
                                <span class="com-title com-reply">快捷回复：</span>
                                <a class="psumbit-kjhf" href="javascript:addNumber('文章不错,写的很好！')" title="文章不错,写的很好！"><i class="icon font-thumbs-o-up"></i></a>
                                <a class="psumbit-kjhf" href="javascript:addNumber('emmmmm……看不懂怎么破？')" title="emmmmm……看不懂怎么破？"><i class="icon font-thumbs-o-down"></i></a>
                                <a class="psumbit-kjhf" href="javascript:addNumber('赞、狂赞、超赞、不得不赞、史上最赞！')" title="赞、狂赞、超赞、不得不赞、史上最赞！"><i class="icon font-xin"></i></a>
                                <span class="com-title">表情：</span>
                                <a href="javascript:;" class="face-show"><i class="icon font-smile-o"></i></a>
                                <div id="ComtoolsFrame" class="ComtoolsFrame liblog_a6b58_bb989">
                                    <img class="comment_ubb" src="/ubb/Addoil.png" alt="Addoil" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Applause.png" alt="Applause" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Badlaugh.png" alt="Badlaugh" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Bomb.png" alt="Bomb" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Coffee.png" alt="Coffee" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Fabulous.png" alt="Fabulous" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Facepalm.png" alt="Facepalm" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Feces.png" alt="Feces" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Frown.png" alt="Frown" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Heyha.png" alt="Heyha" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Insidious.png" alt="Insidious" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/KeepFighting.png" alt="KeepFighting" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/NoProb.png" alt="NoProb" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/PigHead.png" alt="PigHead" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Shocked.png" alt="Shocked" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Sinistersmile.png" alt="Sinistersmile" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Slap.png" alt="Slap" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Social.png" alt="Social" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Sweat.png" alt="Sweat" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Tolaugh.png" alt="Tolaugh" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Watermelon.png" alt="Watermelon" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Witty.png" alt="Witty" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Wow.png" alt="Wow" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Yeah.png" alt="Yeah" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                    <img class="comment_ubb" src="/ubb/Yellowdog.png" alt="Yellowdog" onclick="InsertText(objActive,'['+this.alt+']',false);" />
                                </div>
                            </div>
                            <div class="psumbit-r">
                                <span class="button" onclick="submitForm('frmSumbit')" style="text-align:center;">提交</span>
                            </div>
                        </div>
                    </form>
                </div>
                <div id="commentlist" class="commentlist">
                    <!--评论输出-->
                    <div class="comment-tab ">
                        <div class="come-comt ">
                            评论列表
                            <span id="comment_count">（有 <span style="color:#E1171B"><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["feed"];} ?></span> 条评论，
                                <span style="color:#E1171B"><?php $__detail__ = Detail(request()->param('id'));if((1)){echo $__detail__["views"];} ?></span>人围观）</span>
                        </div>
                    </div>
                    <label id="AjaxCommentBegin"></label>

                    <script type="text/html" id="listData">
                        {{#  layui.each(d.data, function(index, item){ }}
                        <div class="shadow-box msg noimg wow fadeInRight" data-wow-delay="0.25s" id="cmt19053" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInRight;">
                            <div class="msgimg">
                                <img class="avatar" src="/images/default.jpg" alt="网友昵称：{{item.username}}" title="网友昵称：{{item.username}}" />
                            </div>
                            <div class="msgtxt">
                                <div class="msgname LayName">
                                    <a href="javascript:;" rel="nofollow" target="_blank">{{item.username}}</a>
                                    <span class="autlv lay-0 vs">V</span>
                                    <span class="autlv autlvname lay-0">铁粉</span>
                                    <span class="dot">{{index}}楼</span>
                                </div>
                                <div class="interact-bar">
                                    <span class="interact-time" title="评论时间：{{item.createTime}}">{{item.createTime}}</span>
                                    <span class="spot"></span>
                                    <span class="interact-area" title="">ip：{{item.ip}}</span>
                                    <span class="spot"></span>
                                    <a href="#reply" onclick="zbp.comment.reply('{{item.id}}')" class="comment-reply-link">回复</a>
                                </div>
                                <div class="msgarticle">
                                    {{-item.msg}}
                                    <label id="AjaxComment{{item.id}}"></label>
                                    {{#  layui.each(item.son, function(index, item){ }}
                                    <div class="shadow-box msg noimg wow fadeInRight" data-wow-delay="0.25s" id="cmt{{item.id}}" style="{{# if(item.lv > 0){ }}margin-top:0px;{{# } }}visibility: visible; animation-delay: 0.25s; animation-name: fadeInRight;">
                                        <div class="msgimg">
                                            <img class="avatar" src="/images/default.jpg" alt="网友昵称：{{item.username}}" title="网友昵称：{{item.username}}" />
                                        </div>
                                        <div class="msgtxt">
                                            <div class="msgname LayName">
                                                <a href="javascript:;" rel="nofollow" target="_blank">{{item.username}}</a>
                                                <span class="autlv aut-1 vs">V</span>
                                                <span class="autlv autlvname aut-1">博主</span>
                                            </div>
                                            <div class="interact-bar">
                                                <span class="interact-time" title="评论时间：{{item.createTime}}">{{item.createTime}}</span>
                                                <span class="spot"></span>
                                                <span class="interact-area" title="">ip：{{item.ip}}</span>
                                                <span class="spot"></span>
                                                <a href="#reply" onclick="zbp.comment.reply('{{item.id}}')" class="comment-reply-link">回复</a>
                                            </div>
                                            <div class="msgarticle">
                                                <a class="comment_at" href="#comment-{{item.id}}">@{{item.rep}}</a> {{-item.msg}}
                                                <label id="AjaxComment{{item.id}}"></label>
                                            </div>
                                        </div>
                                    </div>
                                    {{#  }); }}
                                </div>
                            </div>
                        </div>
                        {{#  }); }}
                    </script>
                    <div id="view"></div>

                    <div id="com_pagination" class="pagination wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
                        <!--评论翻页条输出-->
                        <!----------分页显示-------->
                        <div id="showpage"></div>
                    </div>
                    <label id="AjaxCommentEnd"></label>
                </div>
            </section>

        </div>
        <div class="side fr mside" style="height: auto !important; position: relative; overflow: visible; box-sizing: border-box; min-height: 0px;">
    <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 0px; position: static; top: 20px; left: 1042.56px;">
        <section class="widget wow fadeInDown" id="divPrevious" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">最近发表</h3>
            <ul class="widget-box divPrevious">
                <?php $__article__ = Article("","id",6,0);$__total__ = $__article__["__total__"];$__LIST__ = $__article__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <div class="side_new">
                    <div class="side_new_dot"></div>
                    <div class="side_new_inner">
                        <div class="side-new-title">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>"><?php echo htmlentities($vo['title']); ?></a>
                        </div>
                        <div class="side-new-time">
                            <em><?php echo htmlentities($vo['name']); ?></em>
                            <span class="spot"></span><?php echo htmlentities($vo['createTime']); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="side_con" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">热门文章</h3>
            <ul class="widget-box side_con">
                <?php $__article__ = Article("","views",5,0);$__total__ = $__article__["__total__"];$__LIST__ = $__article__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li>
                    <div class="hotcom-img">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                            <img src="/<?php echo htmlentities($vo['articleThumbImg']); ?>" alt="<?php echo htmlentities($vo['title']); ?>" />
                        </a>
                    </div>
                    <div class="hotcom-left">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                            <h4 class="hot-com-title">
                                <span class="num<?php echo htmlentities($key); ?>"><?php echo htmlentities($key); ?></span><?php echo htmlentities($vo['title']); ?>
                            </h4>
                        </a>
                        <div class="hot-com-clock">
                            浏览量：<?php echo htmlentities($vo['views']); ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="divComments" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">最新留言</h3>
            <ul class="widget-box divComments">
                <?php $__feedback__ = Feedback(0,0,6,0);$__total__ = $__feedback__["__total__"];$__LIST__ = $__feedback__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li class="side-new-comments"> <strong></strong><b></b>
                    <div class="newComments-info">
                        <div class="newComments-deanxz">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['aid']); ?>#cmt<?php echo htmlentities($vo['id']); ?>" title="用户昵称：<?php echo htmlentities($vo['username']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                <img alt="用户昵称：<?php echo htmlentities($vo['username']); ?>" src="/images/default.jpg" />
                            </a>
                        </div>
                        <div class="newComments-text">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['aid']); ?>#cmt<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>" title="<?php echo htmlentities($vo['article']); ?>"><?php echo $vo['msg']; ?></a>
                        </div>
                        <div class="newComments-mary" title="留言时间：<?php echo htmlentities($vo['createTime']); ?>">
                            <em title="用户昵称：<?php echo htmlentities($vo['username']); ?>"><?php echo htmlentities($vo['username']); ?></em>
                            <span class="spot"></span><?php echo htmlentities($vo['createTime']); ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="side_hot" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">热门推荐</h3>
            <ul class="widget-box side_hot">
                <?php $__attrid__ = AttrId(3,2);$__LIST__ = $__attrid__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <div class="list-media">
                    <a class="media-content" href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>" style="background-image:url(/<?php echo htmlentities($vo['articleThumbImg']); ?>)"><span class="list-overlay"></span></a>
                    <div class="list-content">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" class="list-title h-2x"><?php echo htmlentities($vo['title']); ?></a>
                        <p class="list-footer"><span class="text-read"><?php echo htmlentities($vo['views']); ?> 阅读 ，</span>
                            <time class="d-inline-block"><?php echo htmlentities($vo['month']); ?>-<?php echo htmlentities($vo['day']); ?></time>
                        </p>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="divTags" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">标签列表</h3>
            <ul class="widget-box divTags">
                <?php $__Tags__ = Tags(0,20);$__LIST__ = $__Tags__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li class="divTags6">
                    <a title="<?php echo htmlentities($vo['tag']); ?>" href="/index/tags?tag=<?php echo htmlentities($vo['tag']); ?>"><?php echo htmlentities($vo['tag']); ?><span class="tag-count"> (<?php echo htmlentities($vo['count']); ?>)</span></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
    </div>
</div>
    </div>
</main>

<footer class="footer bg-dark">
    <div class="container clearfix">
        <div class="footer-fill">
            <div class="footer-column">
                <div class="footer-menu">
                    .....
                </div>
                <div class="footer-copyright text-xs">
                    <?php echo config('web.web_Copyright'); ?>
                </div>
            </div>
        </div>
        <div class="footer-hidden-xs">
            <div class="f-last-line">
                <p>
                    <?php echo htmlentities(config('web.web_footer_title')); ?>
                </p>
            </div>
        </div>
        <div class="footer-links">
            <div class="footer-RunTime">
                <?php echo config('web.web_Copy'); ?>
            </div>
        </div>
    </div>
    <div id="backtop" class="backtop">
        <div class="bt-box top" title="返回顶部" style="display: none;">
            <i class="icon font-top"></i>
        </div>
        <div class="bt-box qq" title="联系QQ">
            <a href="https://wpa.qq.com/msgrd?v=3&amp;uin=373889161&amp;site=qq&amp;menu=yes" rel="nofollow" target="_blank" title="联系QQ"><i class="icon font-qq"></i></a>
        </div>
        <?php if(app('request')->controller() == 'Detail'): ?>
        <div class="bt-box bt-comments">
            <a href="#comments" target="_self" title="发表评论"><i class="icon font-comment"></i></a>
        </div>
        <?php endif; ?>
        <div class="bt-box bottom" title="网页底部">
            <i class="icon font-bottom"></i>
        </div>
    </div>
    <div class="sea_wave">
        <svg class="sea_wave_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 24 150 28" preserveaspectratio="none">
            <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
            </defs>
            <g class="sea_wave_g">
                <use xlink:href="#gentle-wave" x="50" y="0" fill="#4579e2"></use>
                <use xlink:href="#gentle-wave" x="50" y="3" fill="#3461c1"></use>
                <use xlink:href="#gentle-wave" x="50" y="6" fill="#2d55aa"></use>
            </g>
        </svg>
    </div>
</footer>

<!---->

<script>var cookieDomain = "https://www.itmkk.com/";</script>
<script src="/template/default/static/js/zh-tw.js"></script>
<script src="/template/default/static/js/custom.js"></script>
<script src="/template/default/static/js/wow.min.js"></script>
<script src="/template/default/static/js/fancybox.umd.js"></script>
<script>
    $("document").ready(function(){
        var img=$("#post-body-888888 img");
        for(var i=0;i<img.length;i++){
            // 设置图片属性
            img.eq(i).attr("data-fancybox",'gallery')
        }
    })
    layui.use(['table','laytpl'], function() {
        var table = layui.table;
        var laytpl = layui.laytpl;

        table.render({
            elem: '#showpage',
            url:'/api/feedback',
            where: {
                aid: "<?php echo app('request')->param('id')?app('request')->param('id'):''; ?>",
                cate: ''
            },
            page:true,
            limit:6,
            response: {
                statusCode: 200 // 重新规定成功的状态码为 200，table 组件默认为 0
            },
            done:function(res,curr,count,origin){
                //console.log(res);
                var getTpl = document.getElementById('listData').innerHTML; // 获取模板字符
                var elemView = document.getElementById('view'); // 视图对象
                // 渲染并输出结果
                laytpl(getTpl).render(res, function(str){
                    elemView.innerHTML = str;
                });
            }
        });
    })
    //添加图片属性
    //$('single-entry').img.setAttribute("data-fancybox","gallery");
    function submitForm(formId){
        const formData = new FormData($('#'+formId)[0]);
        // 将转换为普通对象
        $.ajax({
            url:'/api/feedback/saveAt',
            type:'POST',
            data:formData,
            processData: false, // jQuery不要去处理发送的数据
            contentType: false, // jQuery不要去设置Content-Type请求头
            dataType: "json",
            success:function(res){
                const result = JSON.parse(res);
                if (result.code == 200) {
                    layer.msg(result.message,{icon:6,time:3000,shade:0.3});
                    setTimeout( () => {
                        //更新token
                        $("#inpRevToken").val(result.token);
                        //更新验证码
                        $("#refreshCaptcha").attr('src',"<?php echo captcha_src(); ?>"+Math.random());
                        //重置表单
                        $('#'+formId)[0].reset();
                    },500)//2秒后执行
                } else {
                    layer.msg(result.message,{icon:5,time:3000,shade:0.3});
                    //更新验证码
                    $("#refreshCaptcha").attr('src',"<?php echo captcha_src(); ?>"+Math.random());
                }
            }
        })
    }
</script>
</body>
</html>