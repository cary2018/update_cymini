<?php /*a:7:{s:35:"template/default/article\index.html";i:1720674868;s:36:"template/default/layout\file-js.html";i:1719637054;s:39:"template/default/layout\file-style.html";i:1719637134;s:33:"template/default/layout\icon.html";i:1719636551;s:36:"template/default/layout\navmenu.html";i:1720674868;s:39:"template/default/layout\list-right.html";i:1720674868;s:35:"template/default/layout\footer.html";i:1718957421;}*/ ?>
<!DOCTYPE html>
<html xml:lang="zh-Hans" lang="zh-Hans" style="transform: none;">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="applicable-device" content="pc,mobile" />
    <meta name="renderer" content="webkit" />
    <meta name="force-rendering" content="webkit" />
    <title><?php $__category__ = FindTable("category",[["id","=",request()->param('id')],["isShow","=",1]]);if($__category__){echo $__category__["name"];} ?>-<?php echo htmlentities(config('web.web_title')); ?></title>
    <meta name="Keywords" content="<?php echo htmlentities(config('web.web_key')); ?>" />
    <meta name="description" content="<?php echo htmlentities(config('web.web_desc')); ?>" />
    <meta property="og:type" content="category" />
    <meta property="og:title" content="<?php echo htmlentities(config('web.web_title')); ?>" />
    <meta property="og:description" content="<?php echo htmlentities(config('web.web_desc')); ?>" />

    <script src="/template/default/static/js/jquery.min-3.6.1.js"></script>
<script src="/template/default/static/js/zblogphp.js"></script>
<script src="/template/default/static/js/c_html_js_add.js"></script>
    <link rel="stylesheet" href="/template/default/static/css/style.css" type="text/css" media="all" as="style" />
<link rel="stylesheet" href="/template/default/static/css/public.css" type="text/css" media="all" />

    <script src="/template/default/static/layui/layui.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="/template/default/static/layui/css/layui.css" />

    <link rel="stylesheet" href="/template/default/static/css/animate.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/template/default/static/css/night.css" type="text/css" media="all" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

    <!--[if lt IE 9]><script src="https://cdn.staticfile.org/html5shiv/3.7.0/html5shiv.js"></script><![endif]-->

</head>
<body class="home home-category" style="transform: none;">

<header class="top-header">
    <div class="top-bar fixed-nav fixed-appear">
        <div class="container secnav secnav-b clearfix">
            <div class="fav-subnav">
                <div class="top-bar-left pull-left navlogo">
                    <div class="m-top-search">
                        <i class="icon font-search top-search"></i>
                    </div>
                    <a href="/" class="logo" title="...">
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-light" id="logo-light" alt="..." />
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-dark d-none" id="logo-dark" alt="..." />
                        <b class="shan"></b>
                    </a>
                    <div class="m-top-logo">
                        <i class="nav-bar"><span></span><span></span><span></span></i>
                    </div>
                </div>
                <div class="top-nav-left header-nav fl" data-type="index" data-infoid="index">
                    <aside class="mobile_aside mobile_nav">
                        <ul id="nav" class="top-bar-menu nav-pills">
                            <li id="nvabar-item-index">
                                <a href="/">
                                    <i class="icon font-home"></i>
                                    首页
                                </a>
                            </li>
                            <?php $__navmenu__ = GetCache('NavMenu');$__LIST__ = $__navmenu__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                            <li id="navbar-category-<?php echo htmlentities($vo['id']); ?>" class="<?php if($vo['son']): ?>menu-item-has-children<?php endif; ?>">
                                <a href="<?php echo !empty($vo['isUrl']) ? htmlentities($vo['outUrl']) : htmlentities($vo['temp_list']); ?>?id=<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                    <i class="icon <?php echo htmlentities($vo['iconfont']); ?>"></i>
                                    <?php echo htmlentities($vo['name']); ?>
                                </a>
                                <?php if($vo['son']): ?>
                                <span class="toggle-btn"><i class="icon font-chevron-down"></i></span>
                                <ul class="dropdown-menu sub-menu">
                                    <?php foreach($vo['son'] as $skey=>$item): ?>
                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                                        <a href="<?php echo !empty($item['isUrl']) ? htmlentities($item['outUrl']) : htmlentities($item['temp_list']); ?>?id=<?php echo htmlentities($item['id']); ?>" target="<?php echo htmlentities($item['target']); ?>">
                                            <?php echo htmlentities($item['name']); ?>
                                        </a>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </aside>
                    <div id="mask"></div>
                </div>
                <div class="search-warp clearfix">
                    <div class="search_top">
                        <div class="search-icon"></div>
                        <div class="search-box">
                            <form name="search" method="get" action="/index/search">
                                <input class="search-input" value="<?php echo app('request')->param('q')?app('request')->param('q'):''; ?>" placeholder="请输入关键字" type="text" name="q" />
                                <button class="showhide-search" type="submit">搜 索</button>
                                <span class="s-icon"></span>
                            </form>
                        </div>
                    </div>
                    <a class="at-night top-night" title="夜间模式" href="javascript:switchNightMode()" target="_self"></a>
                    <a class="top-tnrt" title="繁简转换" href="javascript:translatePage();" id="zh_tw">繁体</a>
                    <!--<div class="text-user-r">
                        <a target="_self" class="t-btn r-btn-ht" title="HI，您好！" href="javascript:lcp.loginPopup('register');">注册</a>
                        <a target="_self" class="t-btn l-btn-ht" title="登录账户" href="javascript:lcp.loginPopup();">登录</a>
                    </div>-->
                </div>
            </div>
        </div>
        <div id="percentageCounter" style="width: 0%;"></div>
    </div>
</header>

<main class="main-content container clearfix" style="height: auto !important; transform: none;">
    <nav class="navcates place">
        <i class="icon font-home"></i>
        <a href="/">首页</a>
        <?php $__Breadcrumb__ = Breadcrumb(request()->param("id"));$__LIST__ = $__Breadcrumb__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
        <i class="icon font-angle-right"></i>
        <a href="<?php echo !empty($vo['isUrl']) ? htmlentities($vo['outUrl']) : htmlentities($vo['temp_list']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="查看 <?php echo htmlentities($vo['name']); ?> 分类中的全部文章"><?php echo htmlentities($vo['name']); ?></a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </nav>

    <div class="row" style="height: auto !important; transform: none;">
        <div class="main fl auto-side" style="height: auto !important;">
            <div class="catetop-list">
                <div class="media">
                    <div class="list-top-content" style="background-image: url('/template/default/static/images/th.jpg');">
                        <div class="overlay-grad"></div>
                    </div>
                </div>
                <div class="catetop-list-txt">
                    <h1><?php $__category__ = FindTable("category",[["id","=",request()->param('id')],["isShow","=",1]]);if($__category__){echo $__category__["name"];} ?>
                        <sup class="sup-list-num"><?php $__totals__ = CountTable("article",[["status","=",1],["cid","=",request()->param("id")]]);echo $__totals__; ?></sup>
                    </h1>
                    <div class="catetop-list-intro">
                        <?php $__category__ = FindTable("category",[["id","=",request()->param('id')],["isShow","=",1]]);if($__category__){echo $__category__["keywords"];} ?>
                    </div>
                </div>
            </div>


            <div id="pjaxmain">
                <div class="home-main auto-main list-left">
                    <script id="listData" type="text/html">
                        {{#  layui.each(d.data, function(index, item){ }}
                        <article class="post-list blockimg picsrcd auto-list wow fadeInDown" id="list{{index}}}" style="visibility: visible; animation-name: fadeInDown;">
                            <div class="entry-container">
                                <figure class="block-image feaimg">
                                    <a class="block-fea" href="{{item.temp_archives}}?id={{item.id}}" title="{{item.title}}" target="<?php echo htmlentities($vo['target']); ?>">
                                        <img class="lazy" src="/{{item.articleThumbImg}}" alt="{{item.title}}" title="{{item.title}}" original="/{{item.articleThumbImg}}" style="" />
                                    </a>
                                    <span class="item-img-cate">{{item.name}}</span>
                                </figure>
                                <header class="entry-header">
                                    <h3><a title="{{item.title}}" href="{{item.temp_archives}}?id={{item.id}}" target="<?php echo htmlentities($vo['target']); ?>"><span class="badge arc_v4">热文</span>{{item.title}}</a></h3>
                                </header>
                                <div class="entry-summary ss">
                                    <p ><a href="{{item.temp_archives}}?id={{item.id}}" target="<?php echo htmlentities($vo['target']); ?>" rel="bookmark">{{item.description}}</a></p>
                                </div>
                                <div class="entry-meta-items">
                                    <div class="entry-meta fea-meta">
                                        <time title="{{item.updateTime}}" datetime="{{item.updateTime}}"><i class="icon font-time"></i>{{item.updateTime}}</time>
                                        <span class="meta-viewnums" title="{{item.views}} 阅读"><span class="separator"></span><i class="icon font-eye"></i>{{item.views}} 阅读</span>
                                        <a class="meta-viewnums" href="{{item.temp_archives}}?id={{item.id}}#comments"><span class="separator"></span><i class="icon font-comment"></i>{{item.feed}} 评论</a>
                                    </div>
                                    <div class="entry-meta-author">
                                        <a class="meta-author-url" href="javascript:;"><i class="icon icon font-guanfangbanben"></i>{{item.author}}</a>
                                    </div>
                                </div>
                                <div class="l-line"></div>
                            </div>
                        </article>
                        {{#  }); }}
                    </script>
                    <div id="view"></div>
                </div>
                <footer class="pagination wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
                    <!----------分页显示-------->
                    <div id="showpage"></div>
                </footer>
            </div>
        </div>
        <div class="side fr mside" style="height: auto !important; position: relative; overflow: visible; box-sizing: border-box; min-height: 0px;">
    <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 0px; position: static; top: 20px; left: 1042.56px;">
        <section class="widget wow fadeInDown" id="divPrevious" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">最近发表</h3>
            <ul class="widget-box divPrevious">
                <?php $__article__ = Article("","id",6,0);$__total__ = $__article__["__total__"];$__LIST__ = $__article__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <div class="side_new">
                    <div class="side_new_dot"></div>
                    <div class="side_new_inner">
                        <div class="side-new-title">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>"><?php echo htmlentities($vo['title']); ?></a>
                        </div>
                        <div class="side-new-time">
                            <em><?php echo htmlentities($vo['name']); ?></em>
                            <span class="spot"></span><?php echo htmlentities($vo['createTime']); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="side_con" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">热门文章</h3>
            <ul class="widget-box side_con">
                <?php $__article__ = Article("","views",5,0);$__total__ = $__article__["__total__"];$__LIST__ = $__article__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li>
                    <div class="hotcom-img">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                            <img src="/<?php echo htmlentities($vo['articleThumbImg']); ?>" alt="<?php echo htmlentities($vo['title']); ?>" />
                        </a>
                    </div>
                    <div class="hotcom-left">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                            <h4 class="hot-com-title">
                                <span class="num<?php echo htmlentities($key); ?>"><?php echo htmlentities($key); ?></span><?php echo htmlentities($vo['title']); ?>
                            </h4>
                        </a>
                        <div class="hot-com-clock">
                            浏览量：<?php echo htmlentities($vo['views']); ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="divComments" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">最新留言</h3>
            <ul class="widget-box divComments">
                <?php $__feedback__ = Feedback(0,0,6,0);$__total__ = $__feedback__["__total__"];$__LIST__ = $__feedback__["data"]; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li class="side-new-comments"> <strong></strong><b></b>
                    <div class="newComments-info">
                        <div class="newComments-deanxz">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['aid']); ?>#cmt<?php echo htmlentities($vo['id']); ?>" title="用户昵称：<?php echo htmlentities($vo['username']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                <img alt="用户昵称：<?php echo htmlentities($vo['username']); ?>" src="/images/default.jpg" />
                            </a>
                        </div>
                        <div class="newComments-text">
                            <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['aid']); ?>#cmt<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>" title="<?php echo htmlentities($vo['article']); ?>"><?php echo $vo['msg']; ?></a>
                        </div>
                        <div class="newComments-mary" title="留言时间：<?php echo htmlentities($vo['createTime']); ?>">
                            <em title="用户昵称：<?php echo htmlentities($vo['username']); ?>"><?php echo htmlentities($vo['username']); ?></em>
                            <span class="spot"></span><?php echo htmlentities($vo['createTime']); ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="side_hot" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">热门推荐</h3>
            <ul class="widget-box side_hot">
                <?php $__attrid__ = AttrId(3,2);$__LIST__ = $__attrid__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <div class="list-media">
                    <a class="media-content" href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" title="<?php echo htmlentities($vo['title']); ?>" target="<?php echo htmlentities($vo['target']); ?>" style="background-image:url(/<?php echo htmlentities($vo['articleThumbImg']); ?>)"><span class="list-overlay"></span></a>
                    <div class="list-content">
                        <a href="<?php echo htmlentities($vo['temp_archives']); ?>?id=<?php echo htmlentities($vo['id']); ?>" class="list-title h-2x"><?php echo htmlentities($vo['title']); ?></a>
                        <p class="list-footer"><span class="text-read"><?php echo htmlentities($vo['views']); ?> 阅读 ，</span>
                            <time class="d-inline-block"><?php echo htmlentities($vo['month']); ?>-<?php echo htmlentities($vo['day']); ?></time>
                        </p>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
        <section class="widget wow fadeInDown" id="divTags" style="visibility: visible; animation-name: fadeInDown;">
            <h3 class="widget-title">标签列表</h3>
            <ul class="widget-box divTags">
                <?php $__Tags__ = Tags(0,20);$__LIST__ = $__Tags__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <li class="divTags6">
                    <a title="<?php echo htmlentities($vo['tag']); ?>" href="/index/tags?tag=<?php echo htmlentities($vo['tag']); ?>"><?php echo htmlentities($vo['tag']); ?><span class="tag-count"> (<?php echo htmlentities($vo['count']); ?>)</span></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>
    </div>
</div>
    </div>
</main>

<footer class="footer bg-dark">
    <div class="container clearfix">
        <div class="footer-fill">
            <div class="footer-column">
                <div class="footer-menu">
                    .....
                </div>
                <div class="footer-copyright text-xs">
                    <?php echo config('web.web_Copyright'); ?>
                </div>
            </div>
        </div>
        <div class="footer-hidden-xs">
            <div class="f-last-line">
                <p>
                    <?php echo htmlentities(config('web.web_footer_title')); ?>
                </p>
            </div>
        </div>
        <div class="footer-links">
            <div class="footer-RunTime">
                <?php echo config('web.web_Copy'); ?>
            </div>
        </div>
    </div>
    <div id="backtop" class="backtop">
        <div class="bt-box top" title="返回顶部" style="display: none;">
            <i class="icon font-top"></i>
        </div>
        <div class="bt-box qq" title="联系QQ">
            <a href="https://wpa.qq.com/msgrd?v=3&amp;uin=373889161&amp;site=qq&amp;menu=yes" rel="nofollow" target="_blank" title="联系QQ"><i class="icon font-qq"></i></a>
        </div>
        <?php if(app('request')->controller() == 'Detail'): ?>
        <div class="bt-box bt-comments">
            <a href="#comments" target="_self" title="发表评论"><i class="icon font-comment"></i></a>
        </div>
        <?php endif; ?>
        <div class="bt-box bottom" title="网页底部">
            <i class="icon font-bottom"></i>
        </div>
    </div>
    <div class="sea_wave">
        <svg class="sea_wave_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 24 150 28" preserveaspectratio="none">
            <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
            </defs>
            <g class="sea_wave_g">
                <use xlink:href="#gentle-wave" x="50" y="0" fill="#4579e2"></use>
                <use xlink:href="#gentle-wave" x="50" y="3" fill="#3461c1"></use>
                <use xlink:href="#gentle-wave" x="50" y="6" fill="#2d55aa"></use>
            </g>
        </svg>
    </div>
</footer>


<script>var cookieDomain = "https://www.itmkk.com/";</script>
<script src="/template/default/static/js/zh-tw.js"></script>

<script src="/template/default/static/js/custom.js"></script>
<script src="/template/default/static/js/wow.min.js"></script>
<script>
    layui.use(['table', 'laytpl'], function(){
        var table = layui.table;
        var laytpl = layui.laytpl;

        // 数据列表
        table.render({
            elem: '#showpage',
            url:'/api/article',
            page:true,
            limit:12,
            where:{
                id:"<?php echo app('request')->param('id')?app('request')->param('id'):''; ?>",
            },
            response: {
                statusCode: 200 // 重新规定成功的状态码为 200，table 组件默认为 0
            },
            done:function(res,curr,count,origin){
                //console.log(res);
                var getTpl = document.getElementById('listData').innerHTML; // 获取模板字符
                var elemView = document.getElementById('view'); // 视图对象
                // 渲染并输出结果
                laytpl(getTpl).render(res, function(str){
                    elemView.innerHTML = str;
                });
            }
        });
    });
</script>
</body>
</html>