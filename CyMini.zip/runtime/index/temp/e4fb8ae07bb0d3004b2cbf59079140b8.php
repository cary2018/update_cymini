<?php /*a:6:{s:38:"template/default/navigation\index.html";i:1720674868;s:36:"template/default/layout\file-js.html";i:1719637054;s:39:"template/default/layout\file-style.html";i:1719637134;s:33:"template/default/layout\icon.html";i:1719636551;s:36:"template/default/layout\navmenu.html";i:1720674868;s:35:"template/default/layout\footer.html";i:1718957421;}*/ ?>
<!DOCTYPE html>
<html xml:lang="zh-Hans" lang="zh-Hans" style="transform: none;">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="applicable-device" content="pc,mobile" />
    <meta name="renderer" content="webkit" />
    <meta name="force-rendering" content="webkit" />
    <title><?php $__category__ = FindTable("category",[["id","=",request()->param('id')],["isShow","=",1]]);if($__category__){echo $__category__["name"];} ?>-<?php echo htmlentities(config('web.web_title')); ?></title>
    <meta name="Keywords" content="<?php echo htmlentities(config('web.web_key')); ?>" />
    <meta name="description" content="<?php echo htmlentities(config('web.web_desc')); ?>" />
    <meta property="og:type" content="category" />
    <meta property="og:title" content="<?php echo htmlentities(config('web.web_title')); ?>" />
    <meta property="og:description" content="<?php echo htmlentities(config('web.web_desc')); ?>" />
    <script src="/template/default/static/js/jquery.min-3.6.1.js"></script>
<script src="/template/default/static/js/zblogphp.js"></script>
<script src="/template/default/static/js/c_html_js_add.js"></script>
    <link rel="stylesheet" href="/template/default/static/css/style.css" type="text/css" media="all" as="style" />
<link rel="stylesheet" href="/template/default/static/css/public.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/template/default/static/css/navigation.css" type="text/css" media="all" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

    <!--[if lt IE 9]><script src="https://cdn.staticfile.org/html5shiv/3.7.0/html5shiv.js"></script><![endif]-->

</head>
<body class="home home-category" style="transform: none;">

<header class="top-header">
    <div class="top-bar fixed-nav fixed-appear">
        <div class="container secnav secnav-b clearfix">
            <div class="fav-subnav">
                <div class="top-bar-left pull-left navlogo">
                    <div class="m-top-search">
                        <i class="icon font-search top-search"></i>
                    </div>
                    <a href="/" class="logo" title="...">
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-light" id="logo-light" alt="..." />
                        <img width="300" height="100" src="/<?php echo htmlentities(config('web.web_logo')); ?>" class="logo-dark d-none" id="logo-dark" alt="..." />
                        <b class="shan"></b>
                    </a>
                    <div class="m-top-logo">
                        <i class="nav-bar"><span></span><span></span><span></span></i>
                    </div>
                </div>
                <div class="top-nav-left header-nav fl" data-type="index" data-infoid="index">
                    <aside class="mobile_aside mobile_nav">
                        <ul id="nav" class="top-bar-menu nav-pills">
                            <li id="nvabar-item-index">
                                <a href="/">
                                    <i class="icon font-home"></i>
                                    首页
                                </a>
                            </li>
                            <?php $__navmenu__ = GetCache('NavMenu');$__LIST__ = $__navmenu__; if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                            <li id="navbar-category-<?php echo htmlentities($vo['id']); ?>" class="<?php if($vo['son']): ?>menu-item-has-children<?php endif; ?>">
                                <a href="<?php echo !empty($vo['isUrl']) ? htmlentities($vo['outUrl']) : htmlentities($vo['temp_list']); ?>?id=<?php echo htmlentities($vo['id']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                    <i class="icon <?php echo htmlentities($vo['iconfont']); ?>"></i>
                                    <?php echo htmlentities($vo['name']); ?>
                                </a>
                                <?php if($vo['son']): ?>
                                <span class="toggle-btn"><i class="icon font-chevron-down"></i></span>
                                <ul class="dropdown-menu sub-menu">
                                    <?php foreach($vo['son'] as $skey=>$item): ?>
                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                                        <a href="<?php echo !empty($item['isUrl']) ? htmlentities($item['outUrl']) : htmlentities($item['temp_list']); ?>?id=<?php echo htmlentities($item['id']); ?>" target="<?php echo htmlentities($item['target']); ?>">
                                            <?php echo htmlentities($item['name']); ?>
                                        </a>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </aside>
                    <div id="mask"></div>
                </div>
                <div class="search-warp clearfix">
                    <div class="search_top">
                        <div class="search-icon"></div>
                        <div class="search-box">
                            <form name="search" method="get" action="/index/search">
                                <input class="search-input" value="<?php echo app('request')->param('q')?app('request')->param('q'):''; ?>" placeholder="请输入关键字" type="text" name="q" />
                                <button class="showhide-search" type="submit">搜 索</button>
                                <span class="s-icon"></span>
                            </form>
                        </div>
                    </div>
                    <a class="at-night top-night" title="夜间模式" href="javascript:switchNightMode()" target="_self"></a>
                    <a class="top-tnrt" title="繁简转换" href="javascript:translatePage();" id="zh_tw">繁体</a>
                    <!--<div class="text-user-r">
                        <a target="_self" class="t-btn r-btn-ht" title="HI，您好！" href="javascript:lcp.loginPopup('register');">注册</a>
                        <a target="_self" class="t-btn l-btn-ht" title="登录账户" href="javascript:lcp.loginPopup();">登录</a>
                    </div>-->
                </div>
            </div>
        </div>
        <div id="percentageCounter" style="width: 0%;"></div>
    </div>
</header>

<main class="main-content container clearfix" style="height: auto !important; transform: none;">
    <div class="container">
        <?php if(!$pass): ?>
        <div style="margin: 0 auto;max-width:430px;">
            <div style="margin:15px 15px;">
                <form method="post" name="search" action="" class="searchform">
                    <input style="width:60%;background:#fff;display:unset;" class="search-input" value="" placeholder="请输入访问密码：123.." type="text" name="pass" />
                    <button type="submit" class="showhide-search" />访 问</button>
                </form>
            </div>
        </div>
        <?php endif; if($pass): ?>
        <div class="row row-position">
            <div class="col-md-12">
                <?php $__navigation__ = getNav(); if(is_array($__navigation__) || $__navigation__ instanceof \think\Collection || $__navigation__ instanceof \think\Paginator): $key = 0; $__LIST__ = $__navigation__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
                <div class="part" id="cate<?php echo htmlentities($vo['id']); ?>" >
                    <p class="tt" id="<?php echo htmlentities($vo['id']); ?>">
                        <i class="fa fa-globe"></i>
                        <strong><?php echo htmlentities($vo['name']); ?></strong>
                    </p>
                    <div class="items">

                        <div class="row">
                            <?php if(is_array($vo['nav']) || $vo['nav'] instanceof \think\Collection || $vo['nav'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['nav'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <article class="grid col-xs-6 col-sm-4 col-md-2">
                                <div class="item">
                                    <a class="link" target="<?php echo htmlentities($vo['target']); ?>" href="<?php echo htmlentities($vo['nav_url']); ?>" rel="nofollow">
                                        <i class="autoleft fa fa-link" title="<?php echo htmlentities($vo['keywords']); ?>"></i>
                                    </a>
                                    <a class="a" href="<?php echo htmlentities($vo['nav_url']); ?>" title="<?php echo htmlentities($vo['nav_name']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                        <h3>
                                            <?php echo htmlentities($vo['nav_name']); ?>
                                        </h3>
                                    </a>
                                </div>
                            </article>

                            <?php if($vo['sun_name']): ?>
                            <article class="grid col-xs-6 col-sm-4 col-md-2">
                                <div class="item">
                                    <a class="link" target="<?php echo htmlentities($vo['target']); ?>" href="<?php echo htmlentities($vo['sun_url']); ?>" rel="nofollow">
                                        <i class="autoleft fa fa-link" title="<?php echo htmlentities($vo['keywords']); ?>"></i>
                                    </a>
                                    <a class="a" href="<?php echo htmlentities($vo['sun_url']); ?>" title="<?php echo htmlentities($vo['sun_name']); ?>" target="<?php echo htmlentities($vo['target']); ?>">
                                        <h3><?php echo htmlentities($vo['sun_name']); ?></h3>
                                    </a>
                                </div>
                            </article>
                            <?php endif; ?>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<footer class="footer bg-dark">
    <div class="container clearfix">
        <div class="footer-fill">
            <div class="footer-column">
                <div class="footer-menu">
                    .....
                </div>
                <div class="footer-copyright text-xs">
                    <?php echo config('web.web_Copyright'); ?>
                </div>
            </div>
        </div>
        <div class="footer-hidden-xs">
            <div class="f-last-line">
                <p>
                    <?php echo htmlentities(config('web.web_footer_title')); ?>
                </p>
            </div>
        </div>
        <div class="footer-links">
            <div class="footer-RunTime">
                <?php echo config('web.web_Copy'); ?>
            </div>
        </div>
    </div>
    <div id="backtop" class="backtop">
        <div class="bt-box top" title="返回顶部" style="display: none;">
            <i class="icon font-top"></i>
        </div>
        <div class="bt-box qq" title="联系QQ">
            <a href="https://wpa.qq.com/msgrd?v=3&amp;uin=373889161&amp;site=qq&amp;menu=yes" rel="nofollow" target="_blank" title="联系QQ"><i class="icon font-qq"></i></a>
        </div>
        <?php if(app('request')->controller() == 'Detail'): ?>
        <div class="bt-box bt-comments">
            <a href="#comments" target="_self" title="发表评论"><i class="icon font-comment"></i></a>
        </div>
        <?php endif; ?>
        <div class="bt-box bottom" title="网页底部">
            <i class="icon font-bottom"></i>
        </div>
    </div>
    <div class="sea_wave">
        <svg class="sea_wave_svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 24 150 28" preserveaspectratio="none">
            <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
            </defs>
            <g class="sea_wave_g">
                <use xlink:href="#gentle-wave" x="50" y="0" fill="#4579e2"></use>
                <use xlink:href="#gentle-wave" x="50" y="3" fill="#3461c1"></use>
                <use xlink:href="#gentle-wave" x="50" y="6" fill="#2d55aa"></use>
            </g>
        </svg>
    </div>
</footer>

<script>var cookieDomain = "https://www.itmkk.com/";</script>
<script src="/template/default/static/js/zh-tw.js"></script>
<script src="/template/default/static/js/custom.js"></script>

</body>
</html>