<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2024/07/05 17:18
 * file name : version.php
 * User: asusa
 * Author: Hyy-Cary（优）
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */

return [
    'domain'=>'http://update.itmkk.com',
    'host'=>$_SERVER['HTTP_HOST'],
    'updateFile'=>'update_cymini.zip',
    'updateSql'=>'database.sql',
    'name'=>'CyMini内容管理系统',
    'code'=>'202410231336',
    'copyright' => 'CyMini',
];