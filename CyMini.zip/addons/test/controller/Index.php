<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2024/05/21 21:35
 * file name : Index.php
 * User: asusa
 * Author: Hyy-Cary
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */

namespace addons\test\controller;

class Index
{
    public function link()
    {
        echo 'hello link';
    }
}